<?php

// calling style sheets 
wp_enqueue_style('style-id', get_stylesheet_uri(), '', '1.0.3');


function Our_setup_theme()
{

	// Register Navs Here 
	register_nav_menus(array(
		'primary'	=>	'Top Menu Area',
		'secondary'	=>	'Bottom Menu Area',
	));

	// Register Featured Image 
	add_theme_support('post-thumbnails');
};
add_action('after_setup_theme', 'Our_setup_theme');

function SetUp_Widgets(){
	
/* Sidebar */
register_sidebar(array(
	'name'			=>	'Primary Sidebar',
	'id'			=>	'sidebar_1',
	'before_widget'	=>	'<div class="sidebar_single_area clear">',
	'after_widget'	=>	'</div>',
	'before_title'	=>	'<h2 class="wid_heading">',
	'after_title'	=>	'</h2>',
));

/**
 * Big footer widgets 
 **/

/* Big left footer widgets */
register_sidebar(array(
	'name'			=>	'Footer left widget',
	'id'			=>	'sidebar_2',
	'before_widget'	=>	'<div class="big_footer_side_wrap">',
	'after_widget'	=>	'</div>',
	'before_title'	=>	'<h2 class="red">',
	'after_title'	=>	'</h2>',
));
/* Big middle footer widgets */
register_sidebar(array(
	'name'			=>	'Footer middle widget',
	'id'			=>	'sidebar_3',
	'before_widget'	=>	'<div class="big_footer_side_wrap">',
	'after_widget'	=>	'</div>',
	'before_title'	=>	'<h2 class="green">',
	'after_title'	=>	'</h2>',
));
/* Big right footer widgets */
register_sidebar(array(
	'name'			=>	'Footer right widget',
	'id'			=>	'sidebar_4',
	'before_widget'	=>	'<div class="big_footer_side_wrap">',
	'after_widget'	=>	'</div>',
	'before_title'	=>	'<h2 class="orange">',
	'after_title'	=>	'</h2>',
));


// register_sidebar(array(
// 	'name'		=>	'primary',
// 	'id'		=>	'sidebar-1'
// ));

}
add_action('after_setup_theme', 'SetUp_Widgets');
// add_action('init', 'SetUp_Widgets');		// This is slow hook use after_setup_theme instead.

// Excerpt Function To Excerpt Post content 
function excerpt($num)
{
	$limit	=	$num + 1;
	$excerpt	=	explode(' ', get_the_excerpt(), $limit);	/* Must something in quotes at least space */
	array_pop($excerpt);
	$excerpt	=	implode(" ", $excerpt) . "... <a href='" . get_permalink() . "' class='readmore'>Read More &raquo</a>";
	echo $excerpt;
};
