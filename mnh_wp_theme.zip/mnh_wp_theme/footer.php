		<!-- Footer section -->
		<footer class="site-footer clearfix">
			<p>All Rights Reserved, <a href="https://amdneamulhoqe.wordpress.com/">MNeamulH Tutorials</a> &copy; 2022</p>
			<nav id="footer_nav">
				<?php
				$arg = array('theme_location', 'secondary');
				wp_nav_menu('arg');
				?>
			</nav>
		</footer>
		</div>
		<?php wp_footer(); ?>
		</body>

		</html>