<?php 
/**
 * Template Name: My Template Name is M-Neamul-H 
 * */ ?>
<!-- Get Header from header.php -->
<?php get_header(); ?>
<!-- Main body Contents -->
<div class="content_wrapper">
	<div class="left_content">
		<?php
		if (have_posts()) :
			while (have_posts()) : the_post(); ?>
				<article>
					<h3><a href="<?php the_permalink(); ?>"><?php the_title('<i>', '</i>'); ?></a></h3>
					<div class="featured-image">
						<a href="<?php
						the_permalink();
						?>"><?php
						the_post_thumbnail();
						?></a>
					</div>
					<div class="post_meta">Posted By: <?php the_author_posts_link(); ?> || Posted On: <?php the_time('M d, Y'); ?> || Post Type: <?php the_category(', ') ?> || <?php comments_popup_link('No Response', '1 response', '% responses', 'my_comment_class', 'Comments Off'); ?></div>
					<p><?php // the_excerpt(); ?></p>
					<p><?php // the_content(); ?></p>
					<p><?php echo excerpt('30'); ?></p>
				</article>
		<?php
			endwhile;
		else : echo 'Sorry! No post found.';
		endif;
		?>
	</div>
	<!-- Get Side bar from sidebar.php -->
	<?php get_sidebar(); ?>
	<br class="clear" />
</div>
<?php get_template_part('big_footer'); ?>
<!-- Get Footer from footer.php -->
<?php get_footer(); ?>