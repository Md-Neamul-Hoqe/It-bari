<div class="sidebar">
    <!-- <div class="sidebar_single_area clear">
        <h2 class="wid_heading">Sidebar Heading</h2>
        <ul>
            <li><a href="#">Sidebar Link</a></li>
            <li><a href="#">Sidebar Link</a></li>
            <li><a href="#">Sidebar Link</a></li>
            <li><a href="#">Sidebar Link</a></li>
        </ul>
    </div>
    <div class="sidebar_single_area clear">
        <h2 class="wid_heading">Sidebar Heading</h2>
        <ul>
            <li><a href="#">Sidebar Link</a></li>
            <li><a href="#">Sidebar Link</a></li>
            <li><a href="#">Sidebar Link</a></li>
            <li><a href="#">Sidebar Link</a></li>
        </ul>
    </div> -->
    <?php dynamic_sidebar('sidebar_1') ?>
</div>

































<!-- <div class="sidebar">
    <?php
    // dynamic_sidebar('sidebar1');
    ?>
</div> -->