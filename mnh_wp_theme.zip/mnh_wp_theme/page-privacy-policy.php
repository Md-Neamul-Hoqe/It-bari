<!-- Get Header from header.php -->
<?php get_header(); ?>
<!-- Main body Contents -->
<div class="content_wrapper">
	<div class="left_content" style="width: 100%;">
		<?php
		if (have_posts()) :
			while (have_posts()) : the_post(); ?>
				<article>
					<h3><?php the_title('<i>', '</i>'); ?></h3>
					<div class="featured-image">
						<a href="<?php
						the_permalink();
						?>"><?php
						the_post_thumbnail();
						?></a>
					</div>
					<p><?php the_content(); ?></p>
				</article>
		<?php
			endwhile;
		else : echo 'Sorry! No post found.';
		endif;
		?>
	</div>
	<br class="clear" />
</div>
<!-- Get Footer from footer.php -->
<?php get_footer(); ?>