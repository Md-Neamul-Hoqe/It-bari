<!-- Get Header from header.php -->
<?php
/**
 * Template Name: Full Width Template 
 */
 get_header(); 
 
 ?>
<!-- Main body Contents -->
<div class="content_wrapper">
	<div class="left_content" style="width: 100%;">
		<?php
		if (have_posts()) :
			while (have_posts()) : the_post(); ?>
				<article>
					<p><?php the_content(); ?></p>
				</article>
		<?php
			endwhile;
		else : echo 'Sorry! No post found.';
		endif;
		?>
	</div>
	<!-- Get Side bar from sidebar.php -->
	<br class="clear" />
</div>
<?php get_template_part('big_footer'); ?>
<!-- Get Footer from footer.php -->
<?php get_footer(); ?>