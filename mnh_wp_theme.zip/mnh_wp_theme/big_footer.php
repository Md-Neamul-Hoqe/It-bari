<div class="big_footer_area clearfix">
    <?php dynamic_sidebar('sidebar_2') ?>
    <?php dynamic_sidebar('sidebar_3') ?>
    <?php dynamic_sidebar('sidebar_4') ?>
</div>